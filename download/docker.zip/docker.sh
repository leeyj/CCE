#!/bin/bash
LANG=C
export LANG

AP_STR="Docker"
HOST_NAME=$(hostname)
DATE_STR=$(date +%m%d)

#---------------------------------------------
# 1. IP 입력 받기
#---------------------------------------------
echo "해당 시스템의 IP 주소를 입력해주세요."
while true; do
  echo -n "    (ex. 192.168.0.1) : "
  read IPINFO
  if [ $(echo "$IPINFO" | grep -o '\.' | wc -l) -eq 3 ]; then
    break
  else
    echo "잘못 입력하셨습니다. 다시 입력해주세요."
  fi
done

# 결과 파일(XML)
RESULT_FILE="${AP_STR}_${HOST_NAME}_${IPINFO}_${DATE_STR}.xml"

#---------------------------------------------
# XML 헤더
#---------------------------------------------
{
echo "<CSAP-CCE>"
echo "  <info>"
echo "    <index>${AP_STR}</index>"
echo "    <IPAddress>${IPINFO}</IPAddress>"
echo "    <HOSTNAME>${HOST_NAME}</HOSTNAME>"
echo "  </info>"
} > "$RESULT_FILE"

#---------------------------------------------
# 함수: 결과 기록(XML)
#---------------------------------------------
write_result () {
  local CODE="$1"
  local COMMENT="$2"
  local RESULT="$3"
  local DATA="$4"

  {
  echo "  <CODE Id=\"${CODE}\">"
  echo "    <Comment>${COMMENT}</Comment>"
  echo "    <Result>${RESULT}</Result>"
  echo "    <DATA><![CDATA["
  echo "${DATA}"
  echo "    ]]></DATA>"
  echo "  </CODE>"
  } >> "$RESULT_FILE"
}

#---------------------------------------------
# DK-01 Docker 버전 및 패키지 설치 여부
#---------------------------------------------
DOCKER_VER=$(docker version 2>&1)
PKG_INFO=$( (dpkg -l 2>/dev/null | grep -i docker || rpm -qa 2>/dev/null | grep -i docker) )
[ -z "$PKG_INFO" ] && PKG_INFO="Source 버전으로 설치됨"
RESULT="Info"
write_result "DK-01" "가. Docker 버전 확인 / 나. 패키지 설치 여부 확인" "$RESULT" "$DOCKER_VER\n$PKG_INFO"

#---------------------------------------------
# DK-02 그룹 사용자
#---------------------------------------------
DOCKER_GROUP=$(grep docker /etc/group 2>/dev/null)
ROOT_GROUP=$(grep root /etc/group 2>/dev/null)
write_result "DK-02" "가. docker 그룹 / 나. root 그룹 확인" "Info" "$DOCKER_GROUP\n$ROOT_GROUP"

#---------------------------------------------
# DK-03 audit rule (/usr/bin/docker)
#---------------------------------------------
if grep -q "/usr/bin/docker" /etc/audit/audit.rules 2>/dev/null; then R="Good"; else R="Weak"; fi
write_result "DK-03" "가. /usr/bin/docker audit 설정 확인" "$R" "$(grep '/usr/bin/docker' /etc/audit/audit.rules 2>/dev/null)"

#---------------------------------------------
# DK-04 audit rule (/var/lib/docker)
#---------------------------------------------
if grep -q "/var/lib/docker" /etc/audit/audit.rules 2>/dev/null; then R="Good"; else R="Weak"; fi
write_result "DK-04" "가. /var/lib/docker audit 설정 확인" "$R" "$(grep '/var/lib/docker' /etc/audit/audit.rules 2>/dev/null)"

#---------------------------------------------
# DK-05 audit rule (/etc/docker)
#---------------------------------------------
if grep -q "/etc/docker" /etc/audit/audit.rules 2>/dev/null; then R="Good"; else R="Weak"; fi
write_result "DK-05" "가. /etc/docker audit 설정 확인" "$R" "$(grep '/etc/docker' /etc/audit/audit.rules 2>/dev/null)"

#---------------------------------------------
# DK-06 docker.service audit 확인
#---------------------------------------------
dService=$(systemctl show -p FragmentPath docker.service | awk -F= '{print $2}')
if [ -f "$dService" ]; then
  if grep -q "docker.service" /etc/audit/audit.rules 2>/dev/null; then R="Good"; else R="Weak"; fi
else
  R="Good"
fi
write_result "DK-06" "가. docker.service audit 설정 확인" "$R" "$(grep docker.service /etc/audit/audit.rules 2>/dev/null)"

#---------------------------------------------
# DK-07 docker.socket audit 확인
#---------------------------------------------
dSocket=$(systemctl show -p FragmentPath docker.socket | awk -F= '{print $2}')
if [ -f "$dSocket" ]; then
  if grep -q "docker.socket" /etc/audit/audit.rules 2>/dev/null; then R="Good"; else R="Weak"; fi
else
  R="Good"
fi
write_result "DK-07" "가. docker.socket audit 설정 확인" "$R" "$(grep docker.socket /etc/audit/audit.rules 2>/dev/null)"

#---------------------------------------------
# DK-08 기본 설정 파일 audit (/etc/default/docker or /etc/sysconfig/docker)
#---------------------------------------------
if grep -iq "Ubuntu" /etc/*release; then default_Docker="/etc/default/docker"; else default_Docker="/etc/sysconfig/docker"; fi
if [ -f "$default_Docker" ]; then
  if grep -q "$default_Docker" /etc/audit/audit.rules 2>/dev/null; then R="Good"; else R="Weak"; fi
else
  R="Good"
fi
write_result "DK-08" "가. $default_Docker audit 설정 확인" "$R" "$(grep "$default_Docker" /etc/audit/audit.rules 2>/dev/null)"

#---------------------------------------------
# DK-09 컨테이너 간 통신 제한 (icc 옵션)
#---------------------------------------------
DATA="$(ps -ef | grep docker; docker network ls -q | xargs -r docker network inspect --format '{{ .Name}}: {{ .Options }}'; [ -f "$default_Docker" ] && grep icc "$default_Docker"; [ -f /etc/docker/daemon.json ] && grep icc /etc/docker/daemon.json)"
write_result "DK-09" "가. 컨테이너 간 네트워크 통신 제한 설정 확인" "Info" "$DATA"

#---------------------------------------------
# DK-10 authorization plugin 확인
#---------------------------------------------
DATA="$(ps -ef | grep [d]ocker; [ -f "$default_Docker" ] && grep -i authorization-plugin "$default_Docker"; [ -f /etc/docker/daemon.json ] && grep -i authorization-plugin /etc/docker/daemon.json)"
write_result "DK-10" "가. 인증 활성화 여부 확인" "Info" "$DATA"

#---------------------------------------------
# DK-11 legacy registry 확인
#---------------------------------------------
DATA="$(ps -ef | grep [d]ocker; [ -f "$default_Docker" ] && grep disable-legacy-registry "$default_Docker"; docker version)"
write_result "DK-11" "가. legacy registry (v1) 비활성화 확인" "Info" "$DATA"

#---------------------------------------------
# DK-12 컨테이너 권한 제한
#---------------------------------------------
DATA="$(docker ps -q -a | xargs -r docker inspect --format '{{ .Id }}: SecurityOpt={{ .HostConfig.SecurityOpt }}')"
write_result "DK-12" "가. 컨테이너 추가 권한 획득 제한 확인" "Info" "$DATA"

#---------------------------------------------
# DK-13/14 docker.service 소유권/권한
#---------------------------------------------
if [ -f "$dService" ]; then
  OW=$(stat -c "%U:%G %a" "$dService")
  [ "$OW" = "root:root "* ] && R1="Good" || R1="Weak"
  [ $(stat -c "%a" "$dService") -le 644 ] && R2="Good" || R2="Weak"
else R1="Good"; R2="Good"; OW="파일없음"; fi
write_result "DK-13" "가. docker.service 소유권 확인" "$R1" "$OW"
write_result "DK-14" "가. docker.service 파일 권한 확인" "$R2" "$OW"

#---------------------------------------------
# DK-15/16 docker.socket 소유권/권한
#---------------------------------------------
if [ -f "$dSocket" ]; then
  OW=$(stat -c "%U:%G %a" "$dSocket")
  [[ "$OW" == root:* ]] && R1="Good" || R1="Weak"
  [ $(stat -c "%a" "$dSocket") -le 644 ] && R2="Good" || R2="Weak"
else R1="Good"; R2="Good"; OW="파일없음"; fi
write_result "DK-15" "가. docker.socket 소유권 확인" "$R1" "$OW"
write_result "DK-16" "가. docker.socket 권한 확인" "$R2" "$OW"

#---------------------------------------------
# DK-17/18 /etc/docker 소유권/권한
#---------------------------------------------
if [ -d /etc/docker ]; then
  OW=$(stat -c "%U:%G %a" /etc/docker)
  [ "$OW" = "root:root "* ] && R1="Good" || R1="Weak"
  [ $(stat -c "%a" /etc/docker) -le 755 ] && R2="Good" || R2="Weak"
else R1="Info"; R2="Info"; OW="없음"; fi
write_result "DK-17" "가. /etc/docker 소유권 확인" "$R1" "$OW"
write_result "DK-18" "가. /etc/docker 권한 확인" "$R2" "$OW"

#---------------------------------------------
# DK-19/20 docker.sock 소유권/권한
#---------------------------------------------
SOCK_FILE="/var/run/docker.sock"
[ ! -S "$SOCK_FILE" ] && SOCK_FILE="/run/docker.sock"
if [ -S "$SOCK_FILE" ]; then
  OW=$(stat -c "%U:%G %a" "$SOCK_FILE")
  [[ "$OW" =~ root:docker|root:root ]] && R1="Good" || R1="Weak"
  [ $(stat -c "%a" "$SOCK_FILE") -le 660 ] && R2="Good" || R2="Weak"
else R1="Info"; R2="Info"; OW="없음"; fi
write_result "DK-19" "가. docker.sock 소유권 확인" "$R1" "$OW"
write_result "DK-20" "가. docker.sock 권한 확인" "$R2" "$OW"

#---------------------------------------------
# DK-21/22 daemon.json 소유권/권한
#---------------------------------------------
if [ -f /etc/docker/daemon.json ]; then
  OW=$(stat -c "%U:%G %a" /etc/docker/daemon.json)
  [ "$OW" = "root:root "* ] && R1="Good" || R1="Weak"
  [ $(stat -c "%a" /etc/docker/daemon.json) -le 644 ] && R2="Good" || R2="Weak"
else R1="Good"; R2="Good"; OW="없음"; fi
write_result "DK-21" "가. daemon.json 소유권 확인" "$R1" "$OW"
write_result "DK-22" "가. daemon.json 권한 확인" "$R2" "$OW"

#---------------------------------------------
# DK-23/24 /etc/default/docker 소유권/권한
#---------------------------------------------
if [ -f /etc/default/docker ]; then
  OW=$(stat -c "%U:%G %a" /etc/default/docker)
  [ "$OW" = "root:root "* ] && R1="Good" || R1="Weak"
  [ $(stat -c "%a" /etc/default/docker) -le 644 ] && R2="Good" || R2="Weak"
else R1="Good"; R2="Good"; OW="없음"; fi
write_result "DK-23" "가. /etc/default/docker 소유권 확인" "$R1" "$OW"
write_result "DK-24" "가. /etc/default/docker 권한 확인" "$R2" "$OW"

#---------------------------------------------
# DK-25 컨테이너 계정 확인
#---------------------------------------------
DATA=$(docker ps -q -a | xargs -r docker inspect --format '{{ .Id }}: User={{.Config.User}}')
write_result "DK-25" "가. 컨테이너별 계정 확인" "Info" "$DATA"

#---------------------------------------------
# DK-26 DOCKER_CONTENT_TRUST 확인
#---------------------------------------------
if [ "$DOCKER_CONTENT_TRUST" = "1" ]; then R="Good"; else R="Weak"; fi
write_result "DK-26" "가. DOCKER_CONTENT_TRUST 값 확인" "$R" "$DOCKER_CONTENT_TRUST"

#---------------------------------------------
# DK-27 SELinux enabled 확인
#---------------------------------------------
DATA="$(ps -ef | grep '[d]ocker' | grep selinux-enabled; docker ps -q -a | xargs -r docker inspect --format '{{.Id}}: SecurityOpt={{.HostConfig.SecurityOpt}}')"
write_result "DK-27" "가. SELinux 설정 여부 확인" "Info" "$DATA"

#---------------------------------------------
# DK-28 컨테이너에서 ssh 프로세스 확인
#---------------------------------------------
DATA=""
count=0
for id in $(docker ps -q); do
  if docker exec "$id" ps -el 2>/dev/null | grep -qi ssh; then
    DATA+="\n컨테이너:$id\n$(docker exec "$id" ps -el | grep -i ssh)"
    ((count++))
  fi
done
[ $count -eq 0 ] && R="Good" || R="Weak"
write_result "DK-28" "가. ssh 사용 컨테이너 확인" "$R" "$DATA"

#---------------------------------------------
# DK-29 Privileged port 매핑 확인
#---------------------------------------------
DATA="$(docker ps -a)"
write_result "DK-29" "가. 컨테이너 privileged 포트 확인" "Info" "$DATA"

#---------------------------------------------
# DK-30 PidsLimit 확인
#---------------------------------------------
DATA=$(docker ps -q -a | xargs -r docker inspect --format '{{.Id}}: PidsLimit={{.HostConfig.PidsLimit}}')
if echo "$DATA" | awk -F= '{print $2}' | egrep -q "0|-1"; then R="Weak"; else R="Good"; fi
write_result "DK-30" "가. 컨테이너별 PidsLimit 값 확인" "$R" "$DATA"

#---------------------------------------------
# DK-31 docker0 사용 여부
#---------------------------------------------
DATA="$(ip addr | grep docker; docker network ls -q | xargs -r docker network inspect --format '{{.Name}}: {{.Options}}')"
write_result "DK-31" "가. docker0 네트워크 사용 여부 확인" "Info" "$DATA"

#---------------------------------------------
# DK-32 UsernsMode 공유 여부
#---------------------------------------------
DATA=$(docker ps -q -a | xargs -r docker inspect --format '{{.Id}}:UsernsMode={{.HostConfig.UsernsMode}}')
if echo "$DATA" | grep -iq "host"; then R="Weak"; else R="Good"; fi
write_result "DK-32" "가. host user namespace 공유 확인" "$R" "$DATA"

#---------------------------------------------
# XML 마무리
#---------------------------------------------
echo "</CSAP-CCE>" >> "$RESULT_FILE"
echo "Docker CCE 점검이 완료되었습니다. 결과: $RESULT_FILE"
