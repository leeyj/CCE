#!/bin/bash

# OS 및 배포판 감지
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        echo "$ID"
    else
        uname -s | tr '[:upper:]' '[:lower:]'
    fi
}

# Apache 설정파일 및 설치디렉터리 결정
set_apache_paths() {
    local os_name=$1
    if [[ "$os_name" == "ubuntu" || "$os_name" == "debian" ]]; then
        echo "/etc/apache2/apache2.conf|/etc/apache2"
    elif [[ "$os_name" == "centos" || "$os_name" == "rhel" || "$os_name" == "fedora" ]]; then
        echo "/etc/httpd/conf/httpd.conf|/etc/httpd"
    else
        # 기본값 존재 여부 확인
        if [ -f "/etc/apache2/apache2.conf" ]; then
            echo "/etc/apache2/apache2.conf|/etc/apache2"
        elif [ -f "/etc/httpd/conf/httpd.conf" ]; then
            echo "/etc/httpd/conf/httpd.conf|/etc/httpd"
        else
            echo "|"
        fi
    fi
}

# 1. 웹서비스 영역의 분리 점검
check_documentroot() {
    local conf=$1
    local docroot
    docroot=$(grep -i 'DocumentRoot' "$conf" | grep -v '^#' | head -n 1 | awk '{print $2}')
    local result
    if [[ "$docroot" == "/var/www/html" || "$docroot" == "/var/www/" ]]; then
        result="weak"
    else
        result="Good"
    fi

    echo "<Code id=\"AP-01\">"
    echo "  <Result>$result</Result>"
    echo "  <Comment>웹서비스 영역의분리</Comment>"
    echo "  <DATA><![CDATA[$(grep -i 'DocumentRoot' "$conf" | grep -v '^#')]]></DATA>"
    echo "</Code>"
}

# 2. 불필요한 파일 제거 점검
check_manual_files() {
    local conf=$1
    local install_dir=$2
    local manual_file_exist
    local manual_conf_exist

    if find "$install_dir" -name manual -print -quit | grep -q .; then
        manual_file_exist=0
    else
        manual_file_exist=1
    fi

    if grep -i manual "$conf" | grep -v '^#' | grep -q .; then
        manual_conf_exist=0
    else
        manual_conf_exist=1
    fi

    local result
    if [[ $manual_file_exist -eq 1 && $manual_conf_exist -eq 1 ]]; then
        result="Good"
    else
        result="weak"
    fi

    echo "<Code id=\"AP-02\">"
    echo "  <Result>$result</Result>"
    echo "  <Comment>불필요한 파일 제거</Comment>"
    echo "  <DATA><![CDATA[$(cat "$conf")]]></DATA>"
    echo "</Code>"
}

# 3. 링크사용 금지(심볼릭링크, Alias 제한) 점검
check_links_usage() {
    local conf=$1

    local symlinks_usage aliases_usage result
    symlinks_usage=$(grep -i 'FollowSymLinks' "$conf" | grep -v '^#')
    aliases_usage=$(grep -i '^Alias' "$conf" | grep -v '^#')

    if [[ -z "$symlinks_usage" && -z "$aliases_usage" ]]; then
        result="Good"
    else
        result="weak"
    fi

    echo "<Code id=\"AP-03\">"
    echo "  <Result>$result</Result>"
    echo "  <Comment>링크사용 금지</Comment>"
    echo "  <DATA><![CDATA[$symlinks_usage
$aliases_usage]]></DATA>"
    echo "</Code>"
}

# 4. 파일 업로드 및 다운로드 제한 점검
check_upload_download_limit() {
    local conf=$1
    local result
    local limit_setting

    limit_setting=$(grep -i 'LimitRequestBody' "$conf" | grep -v '^#')

    if [[ -z "$limit_setting" ]]; then
        result="weak"
    else
        result="Good"
    fi

    echo "<Code id=\"AP-04\">"
    echo "  <Result>$result</Result>"
    echo "  <Comment>파일 업로드 및 다운로드 제한</Comment>"
    echo "  <DATA><![CDATA[$limit_setting]]></DATA>"
    echo "</Code>"
}

# 5. 디렉터리 리스팅 제거 점검
check_directory_listing() {
    local conf=$1
    local result
    local indexes_setting

    indexes_setting=$(grep -i 'Options' "$conf" | grep -i 'Indexes' | grep -v '^#')

    if [[ -z "$indexes_setting" ]]; then
        result="weak"
    else
        result="Good"
    fi

    echo "<Code id=\"AP-05\">"
    echo "  <Result>$result</Result>"
    echo "  <Comment>디렉터리 리스팅 제거</Comment>"
    echo "  <DATA><![CDATA[$indexes_setting]]></DATA>"
    echo "</Code>"
}

# 6. 웹 프로세스 권한 제한 점검
check_web_process_privilege() {
    local proc_pattern="apache2|httpd"
    local result

    # root 권한으로 실행 중인 프로세스가 있으면 weak
    if ps -ef | grep -E "$proc_pattern" | grep -v grep | awk '{print $1}' | grep -q '^root$'; then
        result="weak"
    else
        result="Good"
    fi

    local ps_output
    ps_output=$(ps -ef | grep -E "$proc_pattern" | grep -v grep)

    echo "<Code id=\"AP-06\">"
    echo "  <Result>$result</Result>"
    echo "  <Comment>웹 프로세스 권한 제한</Comment>"
    echo "  <DATA><![CDATA[$ps_output]]></DATA>"
    echo "</Code>"
}

# 7. 최신 보안패치 적용 점검
check_security_patch() {
    local result="Info"
    local version_info

    if command -v apache2 > /dev/null 2>&1; then
        version_info=$(apache2 -v 2>&1)
    elif command -v httpd > /dev/null 2>&1; then
        version_info=$(httpd -v 2>&1)
    else
        version_info="Apache 실행파일을 찾을 수 없습니다."
    fi

    echo "<Code id=\"AP-07\">"
    echo "  <Result>$result</Result>"
    echo "  <Comment>최신 보안패치 적용</Comment>"
    echo "  <DATA><![CDATA[$version_info]]></DATA>"
    echo "</Code>"
}

# 메인 함수 - 각 점검 함수 호출
main() {
    local os_name conf install_dir

    os_name=$(detect_os)
    paths=$(set_apache_paths "$os_name")
    conf="${paths%%|*}"
    install_dir="${paths##*|}"

    if [[ -z "$conf" || -z "$install_dir" ]]; then
        echo "아파치 설정 파일을 찾을 수 없습니다."
        exit 1
    fi

    echo "<SCAP-CCE>"
    check_documentroot "$conf"
    check_manual_files "$conf" "$install_dir"
    check_links_usage "$conf"
    check_upload_download_limit "$conf"
    check_directory_listing "$conf"
    check_web_process_privilege
    check_security_patch
    echo "</SCAP-CCE>"
}

main
