#!/bin/bash
LANG=C
export LANG

AP_STR="MariaDB"
HOST_NAME=$(hostname)
DATE_STR=$(date +%m%d)
CONFIG_FILE="config.yaml"

# XML Header 함수 준비
write_code() {
    local code_id="$1"
    local comment="$2"
    local result="$3"
    local check="$4"
    local data="$5"
    {
        echo "  <Code Id=\"$code_id\">"
        echo "    <Comment>${comment} / ${check}</Comment>"
        echo "    <Result>$result</Result>"
        echo "    <DATA><![CDATA["
        echo "$data"
        echo "    ]]></DATA>"
        echo "  </Code>"
    } >> "$RESULT_FILE"
}

# --- config.yaml 자동 로드 or 인터랙티브 입력 ---
if [ -f "$CONFIG_FILE" ]; then
    echo "[INFO] Config file detected: $CONFIG_FILE"
     IPINFO=$(grep '^ip=' "$CONFIG_FILE" | cut -d'=' -f2 | xargs | tr -d "'\"")
     mysql=$(grep '^bin=' "$CONFIG_FILE" | cut -d'=' -f2 | xargs | tr -d "'\"")
     mysql_cnf=$(grep '^cnf=' "$CONFIG_FILE" | cut -d'=' -f2 | xargs | tr -d "'\"")
     my_pwd=$(grep '^use_root_pw=' "$CONFIG_FILE" | cut -d'=' -f2 | xargs | tr -d "'\"")
     id=$(grep '^id=' "$CONFIG_FILE" | cut -d'=' -f2 | xargs | tr -d "'\"")
     pwd2=$(grep '^passwd=' "$CONFIG_FILE" | cut -d'=' -f2 | xargs | tr -d "'\"")


    echo "[INFO] Using settings from config.yaml"
    echo " IP = $IPINFO"
    echo " MySQL bin = $mysql"
    echo " MySQL conf = $mysql_cnf"
    echo " RootPWFlag(use_root_pw) = $my_pwd"
    echo " ID = $id"
    [ "$my_pwd" = "1" ] && AUTH="-u $id -p$pwd2" || AUTH="-u $id"
else
    echo "[WARN] Config file not found, entering interactive mode..."
    echo "해당 시스템의 IP 주소를 입력해주세요."
    while true; do
        echo -n "    (ex. 192.168.0.1) : "
        read IPINFO
        if [ "$(echo "$IPINFO" | tr -d -c '.' | wc -m)" -eq 3 ]; then break; fi
        echo "잘못 입력하셨습니다. 다시 입력해주세요."
        echo ""
    done
    while true; do
        echo -n "MariaDB 실행파일 경로 입력: "
        read mysql
        [ -f "$mysql" ] && break || echo "경로가 없음"
    done
    while true; do
        echo -n "MariaDB 설정파일 경로 입력: "
        read mysql_cnf
        [ -f "$mysql_cnf" ] && break || echo "경로가 없음"
    done
    echo -n "root계정 비밀번호 존재(1) / 없음(2): "
    read my_pwd
    echo -n "관리자 접속 IP: "
    read my_ip
    if [ "$my_pwd" = "1" ]; then
        echo -n "root 계정과 비밀번호 (root/패스워드): "
        read idpwd
        id="${idpwd%%/*}"
        pwd2="${idpwd#*/}"
        AUTH="-u $id -p$pwd2"
    else
        echo -n "root 계정 ID(비밀번호 없음): "
        read id
        AUTH="-u $id"
    fi
fi

# 결과 파일명
RESULT_FILE="${AP_STR}_${HOST_NAME}_${IPINFO}_${DATE_STR}.xml"

# XML 헤더 작성
{
echo '<?xml version="1.0" encoding="UTF-8"?>'
echo '<CSAP-CCE>'
echo "  <IPAddress>$IPINFO</IPAddress>"
} > "$RESULT_FILE"

# SYS-INFO
OS_INFO=$(uname -r; echo ""; cat /etc/*release; echo ""; uname -m)
write_code "SYS-INFO" "시스템 기본 정보" "Info" "OS 커널/배포판/아키텍처 출력" "$OS_INFO"

# --- DY-01 ---
DATA=$($mysql -h "$IPINFO" $AUTH -e "SELECT host, user, authentication_string FROM mysql.user;" -t 2>&1)
if echo "$DATA" | egrep -v -w "root|-" | grep -qvE "^\| \*\|"; then RESULT="Info"; else RESULT="Good"; fi
write_code "DY-01" "DB 계정 목록 조회" "$RESULT" "DB 설치 시 기본/불필요 계정이 없으면 양호" "$DATA"

# --- DY-02 ---
DATA=$(
  $mysql -h "$IPINFO" $AUTH -e "SELECT host, user FROM mysql.user WHERE authentication_string=password(user);" -t
  echo ""
  $mysql -h "$IPINFO" $AUTH -e "SELECT host, user FROM mysql.user WHERE password=password(user);" -t
  echo ""
  $mysql -h "$IPINFO" $AUTH -e "SELECT host, user, authentication_string FROM mysql.user WHERE authentication_string='';" -t
  echo ""
  $mysql -h "$IPINFO" $AUTH -e "SELECT host, user, password FROM mysql.user WHERE password='';" -t
  echo ""
  $mysql -h "$IPINFO" $AUTH -e "SHOW VARIABLES LIKE 'validate_password%';" -t
)
write_code "DY-02" "패스워드 정책 및 취약한 계정 점검" "Info" "계정명과 동일/NULL 패스워드 사용 안하면 양호" "$DATA"

# --- DY-03 ---
DATA=$($mysql -h "$IPINFO" $AUTH -e "SELECT host, user, Grant_priv FROM mysql.user WHERE Grant_priv='Y';" -t 2>&1)
if echo "$DATA" | egrep -v -w "root|-|Grant_priv" | grep -q .; then RESULT="Info"; else RESULT="Good"; fi
write_code "DY-03" "GRANT 권한 보유 계정" "$RESULT" "GRANT ALL 권한이 관리자 외에는 없음이 양호" "$DATA"

# --- DY-04 ---
DATA=$($mysql -h "$IPINFO" $AUTH -e "SELECT host, user, select_priv FROM mysql.user WHERE select_priv='Y';" -t 2>&1)
if echo "$DATA" | egrep -v -w "localhost|root|-|select_priv" | grep -q .; then RESULT="Info"; else RESULT="Good"; fi
write_code "DY-04" "mysql.user 테이블 SELECT 권한 보유 계정" "$RESULT" "mysql.user 접근 권한이 최소화되어 있으면 양호" "$DATA"

# --- DY-05 ---
DATA=$(grep user "$mysql_cnf" 2>&1; echo ""; ps -ef | grep mysql | grep -v grep)
write_code "DY-05" "my.cnf user 설정 및 MariaDB 프로세스 확인" "Info" "my.cnf의 user 설정 적정, 프로세스 정상 동작 시 양호" "$DATA"

# --- DY-06 ---
if [ "$(ls -alL "$mysql_cnf" | grep "^...-.-----" | wc -l)" -gt 0 ]; then RESULT="Good"; else RESULT="Weak"; fi
DATA=$(ls -alL "$mysql_cnf" 2>&1)
write_code "DY-06" "my.cnf 파일 권한" "$RESULT" "초기화 파일 권한이 640 이하이면 양호" "$DATA"

# --- DY-07 ---
DATA=$(
  $mysql -h "$IPINFO" $AUTH -e "SELECT host, user, authentication_string, password FROM mysql.user;" -t
  echo ""
  $mysql -h "$IPINFO" $AUTH -e "SELECT host, user, plugin, SUBSTR(HEX(authentication_string), -10) hash FROM mysql.user;" -t
)
write_code "DY-07" "계정별 패스워드 및 plugin 확인" "Info" "sha256 이상 알고리즘 사용 시 양호" "$DATA"

# --- DY-08 ---
GLOG_ON=$($mysql -h "$IPINFO" $AUTH -e "show variables like 'general_log%';" -t | grep -i ON | wc -l)
SLOG_ON=$($mysql -h "$IPINFO" $AUTH -e "show variables like 'slow%';" -t | grep -i ON | wc -l)
[ "$GLOG_ON" -ge 1 ] && [ "$SLOG_ON" -ge 1 ] && RESULT="Good" || RESULT="Weak"
DATA=$(
  $mysql -h "$IPINFO" $AUTH -e "show variables like 'general_log%';" -t
  echo ""
  $mysql -h "$IPINFO" $AUTH -e "show variables like 'slow%';" -t
  echo ""
  $mysql -h "$IPINFO" $AUTH -e "show variables like 'log%';" -t
)
write_code "DY-08" "로그 설정 확인" "$RESULT" "General log와 Slow query log 둘 다 활성화 시 양호" "$DATA"

# --- DY-09 ---
VER_FILE=$(mktemp)
$mysql -h "$IPINFO" $AUTH -e "SELECT @@version;" -t > "$VER_FILE" 2>&1
PKG_INFO=""
if grep -qi ubuntu /etc/*release || grep -qi debian /etc/*release; then
    PKG_INFO=$(dpkg -l | egrep -i 'maria|mysql|percona')
elif grep -qiE "rhel|centos" /etc/*release; then
    PKG_INFO=$(rpm -qa | egrep -i 'maria|mysql|percona')
fi
DATA=$(cat "$VER_FILE"; echo ""; echo "$PKG_INFO")
rm -f "$VER_FILE"
write_code "DY-09" "MariaDB/MySQL 버전 및 패키지 설치 확인" "Info" "최신 보안 패치 버전을 사용하면 양호" "$DATA"

# --- MYCNF 전체 출력 ---
MYCNF_CONTENT=$(cat "$mysql_cnf" 2>&1)
write_code "MYCNF" "my.cnf 전체 내용" "Info" "설정 파일 전문" "$MYCNF_CONTENT"

# XML Footer
echo '</CSAP-CCE>' >> "$RESULT_FILE"

echo "[완료] XML 결과 파일 생성: $RESULT_FILE"
