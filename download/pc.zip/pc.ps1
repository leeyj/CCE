﻿# UTF-8 출력 고정
[Console]::OutputEncoding = [Text.UTF8Encoding]::new()
$OutputEncoding = [Console]::OutputEncoding

# 관리자 권한 확인
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) {
    Write-Warning "관리자 권한으로 PowerShell을 실행해 주세요."
    Pause
    exit 1
}

# OEM 인코딩 파일 → UTF-8 변환 함수
function Convert-OemToUtf8 {
    param([string]$inputFile, [string]$outputFile)
    Get-Content $inputFile -Encoding Default | Out-File -FilePath $outputFile -Encoding utf8
}

# 메타데이터 입력
#$IPInfo = Read-Host "IP 주소 입력(ex.192.168.0.1)"
# IP 주소 자동 추출
# 활성화된 네트워크 인터페이스에서 IPv4 주소 추출
$ipAddresses = Get-NetIPAddress -AddressFamily IPv4 | Where-Object {
    $_.IPAddress -ne '127.0.0.1' -and $_.PrefixOrigin -ne 'WellKnown' 
} | Select-Object -ExpandProperty IPAddress

$IPInfo = if ($ipAddresses -and $ipAddresses.Count -gt 0) { $ipAddresses } else { 'IP없음' }


$Today = Get-Date -Format "yyyy-MM-dd"
$ComputerName = $env:COMPUTERNAME
$SaveDir = ".\WinPC_${ComputerName}_$IPInfo"
if (-not (Test-Path $SaveDir)) { New-Item -ItemType Directory -Path $SaveDir | Out-Null }
$SaveFile = Join-Path $SaveDir "SecurityAudit_$Today.xml"

# PC-01: 최대 암호 기간 점검
net accounts > net-accounts-oem.txt
Convert-OemToUtf8 net-accounts-oem.txt net-accounts.txt

secedit /export /cfg "$env:TEMP\LocalSecurityPolicy.cfg" > $null 2>&1
if (Test-Path "$env:TEMP\LocalSecurityPolicy.cfg") {
    Convert-OemToUtf8 "$env:TEMP\LocalSecurityPolicy.cfg" "$env:TEMP\LocalSecurityPolicy_utf8.txt"
    $localSecurityPolicyText = Get-Content "$env:TEMP\LocalSecurityPolicy_utf8.txt" -Raw
} else {
    $localSecurityPolicyText = ""
}
$netAccountsText = Get-Content net-accounts.txt -Raw

# PC-02: 암호 길이 및 복잡도 안전 추출
$minPwdLenLine = ($netAccountsText -split "`r?`n" | Where-Object { $_ -match "Minimum password length" })[0]
if ($minPwdLenLine) {
    $splitParts = $minPwdLenLine -split ":", 2
    $minPwdLen = if ($splitParts.Count -ge 2) { $splitParts[1].Trim() } else { "0" }
} else {
    $minPwdLen = "0"
}
$passwordComplexityLine = ($localSecurityPolicyText -split "`r?`n" | Where-Object { $_ -match "^PasswordComplexity\s*=" })[0]
if ($passwordComplexityLine) {
    $splitParts = $passwordComplexityLine -split "=", 2
    $passwordComplexityValue = if ($splitParts.Count -ge 2) { $splitParts[1].Trim() } else { "0" }
} else {
    $passwordComplexityValue = "0"
}
$pc02Result = if (($minPwdLen -ge 8) -and ($passwordComplexityValue -eq '1')) { "Good" } else { "Weak" }

net share > net-share-oem.txt
Get-Content net-share-oem.txt -Encoding Default | Out-File net-share-utf8.txt -Encoding utf8
$netShareList = Get-Content net-share-utf8.txt -Raw

if (Test-Path "HKLM:\SYSTEM\CurrentControlSet\services\LanManServer\Shares") {
    reg query "HKLM\SYSTEM\CurrentControlSet\services\LanManServer\Shares" /se "|" > share-registry-oem.txt 2>$null
    Get-Content share-registry-oem.txt -Encoding Default | Out-File share-registry-utf8.txt -Encoding utf8
    $shareRegistry = Get-Content share-registry-utf8.txt -Raw
} else {
    $shareRegistry = ""
}

# PC-04: 불필요 서비스 점검
$unneededServices = @("Alerter", "Computer Browser", "Fast User Switching Compatibility", "Messenger", "Netmeeting Remote Desktop Sharing", "Telnet", "Fax", "Remote Registry")
$runningSrvNames = (Get-Service | Where-Object {$_.Status -eq 'Running'} | Select-Object -ExpandProperty Name)
$foundServices = $unneededServices | Where-Object { $runningSrvNames -contains $_ }
$pc04Result = if ($foundServices.Count -eq 0) { "Good" } else { "Weak" }
$foundServicesStr = if ($foundServices.Count -gt 0) { $foundServices -join ", " } else { "" }
$allRunningServices = (Get-Service | Where-Object { $_.Status -eq 'Running' } | Format-Table Name | Out-String)

# PC-05: 상용 메신저 설치 여부 점검
$unwantedMessengers = @("Kakao", "카카오톡", "NATEON", "LINE", "Telegram", "Zoom", "Microsoft Teams")
$installsHKLM = @()
if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall") {
    $installsHKLM = Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
        $prop = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
        if ($prop -and $prop.PSObject.Properties.Name -contains "DisplayName") { $prop.DisplayName }
    }
}
$installsHKCU = @()
if (Test-Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall") {
    $installsHKCU = Get-ChildItem "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall" -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
        $prop = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
        if ($prop -and $prop.PSObject.Properties.Name -contains "DisplayName") { $prop.DisplayName }
    }
}
$allInstalls = $installsHKLM + $installsHKCU
$foundMessengers = $unwantedMessengers | Where-Object { $allInstalls -like "*$_*" }
$pc05Result = if ($foundMessengers.Count) { "Weak" } else { "Good" }
$allInstallsText = $allInstalls -join "`n"

# PC-06: 보안패치 적용 현황
$hotfixList = (Get-HotFix | Select HotFixID, InstalledOn, Description | Format-Table -AutoSize | Out-String)
$osVersion = (Get-CimInstance Win32_OperatingSystem).Caption + " " + (Get-CimInstance Win32_OperatingSystem).Version

# PC-07: 최신 서비스팩 여부
$osInfo = (systeminfo | Select-String "OS Name","OS Version") -join "`n"

# PC-08: 백신 설치 및 업데이트 여부
$avProducts = Get-CimInstance -Namespace root\SecurityCenter2 -ClassName AntiVirusProduct -ErrorAction SilentlyContinue
$avInfo = if ($avProducts) { $avProducts | Format-Table displayName, productState -AutoSize | Out-String } else { "No AntiVirusProduct info found." }

# PC-09: 백신 실시간 감시 활성화 여부
$avStates = if ($avProducts) { $avProducts | Select-Object -ExpandProperty productState } else { @() }
$realTimeProtectionEnabled = $avStates -contains 266240
$pc09Result = if ($realTimeProtectionEnabled) { "Good" } else { "Weak" }
$avStatesText = if ($avProducts) { $avProducts | Format-Table displayName, productState -AutoSize | Out-String } else { "" }

# PC-10: Windows Defender 방화벽 상태
$firewallHome = (netsh advfirewall show currentprofile state) -join "`n"
$firewallPublic = (netsh advfirewall show publicprofile state) -join "`n"
$firewallHomeStatus = if ($firewallHome -match "State\s+ON") { "Good" } else { "Weak" }
$firewallPublicStatus = if ($firewallPublic -match "State\s+ON") { "Good" } else { "Weak" }
$pc10Result = if (($firewallHomeStatus -eq "Good") -and ($firewallPublicStatus -eq "Good")) { "Good" } else { "Weak" }

# PC-11: 화면보호기 점검
try {
    $ssActive = (Get-ItemProperty 'HKCU:\Control Panel\Desktop').ScreenSaveActive
    $ssTimeout = (Get-ItemProperty 'HKCU:\Control Panel\Desktop').ScreenSaveTimeOut
} catch {
    $ssActive = 0
    $ssTimeout = 0
}
$pc11Result = if (($ssActive -eq 1) -and ($ssTimeout -le 600)) { "Good" } else { "Weak" }

# PC-12: 이동식 미디어 자동실행 방지 점검
$autorunInf = (reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\IniFileMapping\Autorun.inf" 2>$null) -join "`n"
$shellHwDetect = (net start | Select-String "Shell Hardware Detection") -join "`n"
$noDriveTypeAutoRun = ""
$key1 = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"
if (Test-Path $key1) {
    $noDriveTypeAutoRun = reg query $key1 /v NoDriveTypeAutoRun 2>$null | Out-String
}
$noActiveDesktop = ""
if (Test-Path $key1) {
    $noActiveDesktop = reg query $key1 /v NoActiveDesktop 2>$null | Out-String
}
$disableAutoPlay = reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" 2>$null | Select-String DisableAutoplay -SimpleMatch | Out-String

# PC-13: 비인가 무선랜 접속 이력
$wlanProfiles = netsh wlan show profile
$networkListProfiles = reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles" /s 2>$null | Out-String

# 계정 정보 수집 및 오류 처리
$usersRaw = net user 2>&1
if ($usersRaw -match "사용자 이름을 찾을 수 없습니다") {
    $users = @()
} else {
    $users = $usersRaw | Select-String "^\S+" | ForEach-Object { $_.Matches[0].Value }
}

$userXmlEntries = ""
foreach ($user in $users) {
    try {
        $userInfo = net user $user 2>&1
        if ($userInfo -match "사용자 이름을 찾을 수 없습니다") {
            continue
        }
        $enabled = if ($userInfo -match "계정 활성화\s+:(\s*YES)") { "Enabled" } else { "Disabled" }
        $status = if (($minPwdLen -ge 8) -and ($passwordComplexityValue -eq '1')) { "Pass" } else { "Fail" }

        $userXmlEntries += @"
    <Account>
      <UserName>$user</UserName>
      <Enabled>$enabled</Enabled>
      <MinimumPasswordLength>$minPwdLen</MinimumPasswordLength>
      <PasswordComplexity>$passwordComplexityValue</PasswordComplexity>
      <Status>$status</Status>
    </Account>
"@
    } catch {
        continue
    }
}

# 최종 XML 조합
$xmlContent = @"
<?xml version='1.0' encoding='UTF-8'?>
<SecurityAudit>
  <Date>$Today</Date>
  <ComputerName>$ComputerName</ComputerName>
  <IPAddress>$IPInfo</IPAddress>

  <Code Id="PC-01">
    <Comment>최대 암호 기간 점검</Comment>
    <Result>Info</Result>
    <DATA><![CDATA[
$netAccountsText

$localSecurityPolicyText
    ]]></DATA>
  </Code>

  <Code Id="PC-02">
    <Comment>최소 길이 8, 복잡도 1이면 양호</Comment>
    <Result>$pc02Result</Result>
    <DATA><![CDATA[
MinimumPasswordLength=$minPwdLen
PasswordComplexity=$passwordComplexityValue
    ]]></DATA>
  </Code>

  <Code Id="PC-03">
    <Comment>불필요 공유폴더 점검</Comment>
    <Result>Info</Result>
    <DATA><![CDATA[
$netShareList

$shareRegistry
    ]]></DATA>
  </Code>

  <Code Id="PC-04">
    <Comment>불필요 서비스 실행 여부 점검</Comment>
    <Result>$pc04Result</Result>
    <DATA><![CDATA[
RunningServices: $foundServicesStr

All Running Services:
$allRunningServices
    ]]></DATA>
  </Code>

  <Code Id="PC-05">
    <Comment>상용 메신저 설치 여부</Comment>
    <Result>$pc05Result</Result>
    <DATA><![CDATA[
Installed Programs:
$allInstallsText
    ]]></DATA>
  </Code>

  <Code Id="PC-06">
    <Comment>보안패치 적용 현황</Comment>
    <Result>Info</Result>
    <DATA><![CDATA[
$hotfixList

OS Version: $osVersion
    ]]></DATA>
  </Code>

  <Code Id="PC-07">
    <Comment>최신 서비스팩 적용 여부</Comment>
    <Result>Info</Result>
    <DATA><![CDATA[
$osInfo
    ]]></DATA>
  </Code>

  <Code Id="PC-08">
    <Comment>백신 설치 및 업데이트 여부</Comment>
    <Result>Info</Result>
    <DATA><![CDATA[
$avInfo
    ]]></DATA>
  </Code>

  <Code Id="PC-09">
    <Comment>실시간 감시 활성 여부</Comment>
    <Result>$pc09Result</Result>
    <DATA><![CDATA[
$avStatesText
    ]]></DATA>
  </Code>

  <Code Id="PC-10">
    <Comment>Windows Defender 방화벽 활성 상태 점검</Comment>
    <Result>$pc10Result</Result>
    <DATA><![CDATA[
-- 홈/개인 네트워크 방화벽 상태 --
$firewallHome

-- 공용 네트워크 방화벽 상태 --
$firewallPublic
    ]]></DATA>
  </Code>

  <Code Id="PC-11">
    <Comment>화면보호기 활성 여부 및 대기시간 점검</Comment>
    <Result>$pc11Result</Result>
    <DATA><![CDATA[
ScreenSaveActive=$ssActive
ScreenSaveTimeout=$ssTimeout
    ]]></DATA>
  </Code>

  <Code Id="PC-12">
    <Comment>이동식 미디어 자동실행 방지 점검</Comment>
    <Result>Info</Result>
    <DATA><![CDATA[
$autorunInf
$shellHwDetect
$noDriveTypeAutoRun
$noActiveDesktop
$disableAutoPlay
    ]]></DATA>
  </Code>

  <Code Id="PC-13">
    <Comment>비인가 무선랜 접속 이력 점검</Comment>
    <Result>Info</Result>
    <DATA><![CDATA[
$wlanProfiles

$networkListProfiles
    ]]></DATA>
  </Code>

  <Accounts>
$userXmlEntries
  </Accounts>

  <InterviewGuide>
    최소 암호 길이 8 이상, 복잡도 1이면 양호
    정책 설정 전 계정은 인터뷰를 통해 복잡성 적용 여부 확인 필요
  </InterviewGuide>
</SecurityAudit>
"@

# UTF-8로 XML 저장
$xmlContent | Out-File -FilePath $SaveFile -Encoding utf8

Write-Host "✅ XML 보고서 생성 완료: $SaveFile"
Pause
