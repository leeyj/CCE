#!/bin/bash
LANG=C
export LANG
alias ls=ls
AP_STR="Kubernetes(Worker)"
HOST_NAME=$(hostname)
IP_ADDR=$(hostname -I | awk '{print $1}')
DATE_STR=$(date +%m%d)
RESULT_FILE="${HOST_NAME}_${AP_STR}_${DATE_STR}.xml"

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" > $RESULT_FILE
echo "<CSAP-CCE>" >> $RESULT_FILE
echo "  <info>" >> $RESULT_FILE
echo "    <index>K8S-WORKER</index>" >> $RESULT_FILE
echo "    <IPAddress>${IP_ADDR}</IPAddress>" >> $RESULT_FILE
echo "    <HOSTNAME>${HOST_NAME}</HOSTNAME>" >> $RESULT_FILE
echo "  </info>" >> $RESULT_FILE

KW_Info(){
echo '[Kubernetes Worker 점검 준비]'
echo -n "인증서 사용 여부 확인 (Y/N) : "
read Cert_Check
if [ "$Cert_Check" = "Y" ]
then
while true
do
echo "인증서 파일의 경로를 입력해주세요."
echo -n "    (ex. /var/lib/kubelet/pki/) : "
read Cert
if [ $Cert ]; then
if [ -d $Cert ]; then break
else echo "경로가 존재하지 않습니다. 다시입력해주세요."; echo ""; fi
else echo "경로가 존재하지 않습니다. 다시입력해주세요"; fi
done
else
Cert='/dev/null'
fi
}

KW_01(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>Kubelet 인증 제어</Comment>" >> $RESULT_FILE
# 판정
if grep -q -- "--anonymous-auth=false" /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf 2>/dev/null || grep -q -- "--anonymous-auth=false" /etc/systemd/system/kubelet.service.d/10-kubeadm.conf 2>/dev/null; then
  echo "    <Result>Good</Result>" >> $RESULT_FILE
else
  echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
if [ -f /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf ]; then
  cat /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf | grep "KUBELET_SYSTEM_PODS_ARGS"
elif [ -f /etc/systemd/system/kubelet.service.d/10-kubeadm.conf ]; then
  cat /etc/systemd/system/kubelet.service.d/10-kubeadm.conf | grep "KUBELET_SYSTEM_PODS_ARGS"
fi
if [ -f /var/lib/kubelet/config.yaml ]; then
  cat /var/lib/kubelet/config.yaml | egrep -i -A4 "authentication"
  cat /var/lib/kubelet/config.yaml | grep "readOnlyPort"
fi
if [ -f /etc/kubernetes/kubelet-config.yaml ]; then
  cat /etc/kubernetes/kubelet-config.yaml | egrep -i -A4 "authentication"
  cat /etc/kubernetes/kubelet-config.yaml | grep "readOnlyPort"
fi
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KW_02(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>Kubelet 권한 제어</Comment>" >> $RESULT_FILE
# 판정
if grep -q -- "--authorization-mode=Webhook" /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf 2>/dev/null || grep -q -- "--authorization-mode=Webhook" /etc/systemd/system/kubelet.service.d/10-kubeadm.conf 2>/dev/null; then
  echo "    <Result>Good</Result>" >> $RESULT_FILE
else
  echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
if [ -f /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf ]; then
  cat /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf | grep "KUBELET_AUTHZ_ARGS"
elif [ -f /etc/systemd/system/kubelet.service.d/10-kubeadm.conf ]; then
  cat /etc/systemd/system/kubelet.service.d/10-kubeadm.conf | grep "KUBELET_AUTHZ_ARGS"
fi
if [ -f /var/lib/kubelet/config.yaml ]; then
  cat /var/lib/kubelet/config.yaml | egrep -i -A4 "authorization"
fi
if [ -f /etc/kubernetes/kubelet-config.yaml ]; then
  cat /etc/kubernetes/kubelet-config.yaml | egrep -i -A4 "authorization"
fi
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KW_03(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>kubelet SSL/TLS 적용</Comment>" >> $RESULT_FILE
if grep -q -- "--tls-cert-file" /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf 2>/dev/null || grep -q -- "--tls-cert-file" /etc/systemd/system/kubelet.service.d/10-kubeadm.conf 2>/dev/null; then
  echo "    <Result>Good</Result>" >> $RESULT_FILE
else
  echo "    <Result>Info</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
if [ -f /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf ]; then
  cat /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf | grep -E "KUBELET_AUTHZ_ARGS|KUBELET_CERTIFICATE_ARGS"
elif [ -f /etc/systemd/system/kubelet.service.d/10-kubeadm.conf ]; then
  cat /etc/systemd/system/kubelet.service.d/10-kubeadm.conf | grep -E "KUBELET_AUTHZ_ARGS|KUBELET_CERTIFICATE_ARGS"
fi
if [ -f /var/lib/kubelet/config.yaml ]; then
  cat /var/lib/kubelet/config.yaml | grep -A7 "authentication"
  cat /var/lib/kubelet/config.yaml | egrep "tlsCertFile|tlsPrivateKeyFile"
fi
if [ -f /etc/kubernetes/kubelet-config.yaml ]; then
  cat /etc/kubernetes/kubelet-config.yaml | grep -A7 "authentication"
  cat /etc/kubernetes/kubelet-config.yaml | egrep "tlsCertFile|tlsPrivateKeyFile"
fi
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KW_04(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>Kernel 파라미터 설정</Comment>" >> $RESULT_FILE
if grep -q -- "--protect-kernel-defaults=true" /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf 2>/dev/null || grep -q -- "--protect-kernel-defaults=true" /etc/systemd/system/kubelet.service.d/10-kubeadm.conf 2>/dev/null; then
  echo "    <Result>Good</Result>" >> $RESULT_FILE
else
  echo "    <Result>Info</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
if [ -f /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf ]; then
  cat /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf | grep "KUBELET_SYSTEM_PODS_ARGS"
elif [ -f /etc/systemd/system/kubelet.service.d/10-kubeadm.conf ]; then
  cat /etc/systemd/system/kubelet.service.d/10-kubeadm.conf | grep "KUBELET_SYSTEM_PODS_ARGS"
fi
if [ -f /var/lib/kubelet/config.yaml ]; then
  cat /var/lib/kubelet/config.yaml | grep "protectKernelDefaults"
fi
if [ -f /etc/kubernetes/kubelet-config.yaml ]; then
  cat /etc/kubernetes/kubelet-config.yaml | grep "protectKernelDefaults"
fi
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KW_05(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>환경설정 파일 권한 설정</Comment>" >> $RESULT_FILE
BAD_CNT=$(find /etc/kubernetes -type f ! -perm -644 2>/dev/null | wc -l)
if [ "$BAD_CNT" -eq 0 ]; then
  echo "    <Result>Good</Result>" >> $RESULT_FILE
else
  echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
ls -al /etc/kubernetes 2>/dev/null
ls -al /usr/lib/systemd/system/kubelet.service.d/ 2>/dev/null
ls -al /var/lib/kubelet 2>/dev/null
ls -al /var/lib/kube-proxy 2>/dev/null
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KW_06(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>인증서 파일 권한 설정</Comment>" >> $RESULT_FILE
if [ "$Cert" != "/dev/null" ] && [ -d "$Cert" ]; then
  BAD_CERT=$(find "$Cert" -type f ! -perm -644 2>/dev/null | wc -l)
  if [ "$BAD_CERT" -eq 0 ]; then
    echo "    <Result>Good</Result>" >> $RESULT_FILE
  else
    echo "    <Result>Weak</Result>" >> $RESULT_FILE
  fi
else
  echo "    <Result>Info</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
if [ "$Cert" != "/dev/null" ]; then
  ls -alR $Cert 2>/dev/null
fi
ls -al /etc/kubernetes 2>/dev/null
ls -al /etc/kubernetes/ssl 2>/dev/null
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KW_07(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>최신 보안 패치 적용</Comment>" >> $RESULT_FILE
KVER=$(kubectl version --short 2>/dev/null | grep 'Server Version' | awk '{print $3}')
if [ -z "$KVER" ]; then
  echo "    <Result>Info</Result>" >> $RESULT_FILE
elif [[ "$KVER" =~ 1\.(2[0-9]|3[0-9]|\d{3,}) ]]; then
  echo "    <Result>Good</Result>" >> $RESULT_FILE
else
  echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
kubectl version 2>/dev/null
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

# 진단 시작
KW_Info
KW_01 'KW-01'
KW_02 'KW-02'
KW_03 'KW-03'
KW_04 'KW-04'
KW_05 'KW-05'
KW_06 'KW-06'
KW_07 'KW-07'

echo "</CSAP-CCE>" >> $RESULT_FILE
