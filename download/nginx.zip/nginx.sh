#!/bin/bash

LANG=C
export LANG
alias ls=ls

AP_STR="Nginx"
HOST_NAME=$(hostname)
DATE_STR=$(date +%m%d)

# IP 주소 입력 받기
echo " 해당 시스템의 IP 주소를 입력해주세요."
while true; do
    echo -n "    (ex. 192.168.0.1) : "
    read IPINFO
    # '.' 개수 3개인지 체크
    if [ $(echo "$IPINFO" | tr -d -c '.' | wc -m) -eq 3 ]; then
        break
    else
        echo "잘못 입력하셨습니다. 다시 입력해주세요."
        echo ""
    fi
done

RESULT_FILE="${AP_STR}_${HOST_NAME}_${IPINFO}_${DATE_STR}.xml"

echo ""
echo "################# Nginx 점검 스크립트를 실행하겠습니다 ###################"
echo ""

# 기본 시스템 정보 출력
{
    
	echo "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"
	echo "<CSAP-CCE>"
	echo "<Info>"
	echo "<DATA><![CDATA["
	echo "스크립트 실행 시간"
    date "+%Y-%m-%d %X"
    echo ""

    echo "hostname"
    hostname
    echo ""

    echo "Linux Version"
    uname -r
    echo ""

    cat /etc/*release
    echo ""
	echo "]]> </DATA>"
	echo "</Info>"

    echo "<ipAddress> <![CDATA["
    if [ -x /usr/sbin/ifconfig ] || [ -x /sbin/ifconfig ]; then
        ifconfig -a
    else
        ip addr
    fi
    echo "]]> </ipAddress>"
} >> "$RESULT_FILE" 2>&1


alias ls=ls

# 1. Nginx 설치 디렉토리 입력 및 존재 확인
echo "1. Nginx 설치 디렉토리를 입력해주세요."
while true; do
    echo -n " (ex. /etc/nginx) : "
    read Nginx
    if [ -n "$Nginx" ]; then
        if [ -d "$Nginx" ]; then
            break
        else
            echo "입력하신 디렉토리가 존재하지 않습니다. 다시 입력해주세요."
            echo ""
        fi
    else
        echo "잘못 입력하셨습니다. 다시 입력해주세요."
        echo ""
    fi
done

# 2. Nginx 설정 파일 경로 입력 및 존재 확인
echo "2. Nginx 설정 파일 경로를 입력해주세요."
while true; do
    echo -n " (ex. rpm 설치일 경우 /etc/nginx/nginx.conf) : "
    read Nginx_conf
    if [ -n "$Nginx_conf" ]; then
        if [ -f "$Nginx_conf" ]; then
            break
        else
            echo "입력하신 파일이 존재하지 않습니다. 다시 입력해주세요."
            echo ""
        fi
    else
        echo "잘못 입력하셨습니다. 다시 입력해주세요."
        echo ""
    fi
done

echo "Nginx 진단 시작"

# [WN-01] 웹 서비스 영역의 분리 점검
{
    echo "<Code id=\"WM-01\">" 
    echo "<Result>Info</Result>"
    echo "<Comment> 기본 디렉터리를 별도의 디렉터리로 지정하였는지 확인필요</Comment>"
    echo "<DATA><![CDATA["

    # 설정파일 목록 작성 (메인 + include)
    echo "$Nginx_conf" > NGINX_CONF_FILE_LIST.txt
    grep -E "^\s*include\s+" /etc/nginx/nginx.conf | awk '{print $2}' | \
        awk -F";" '{print $1}' | grep -vE "mime.types|modules-enabled" >> NGINX_CONF_FILE_LIST.txt

    # 중복 및 존재하는 파일만 추출
    rm -f NGINX_CONF_FILE_LIST_TMP.txt
    while read -r file; do
        if [ -f "$file" ]; then
            echo "$file" >> NGINX_CONF_FILE_LIST_TMP.txt
        fi
    done < NGINX_CONF_FILE_LIST.txt
    sort -u NGINX_CONF_FILE_LIST_TMP.txt > NGINX_CONF_FILE_LIST.txt

    # 설정파일별 root / proxy 설정 출력
    while read -r conf_file; do
        echo "---------------------------------------------------"
        ls -al "$conf_file"
        echo "---------------------------------------------------"
        if ! grep -v '^[[:space:]]*#' "$conf_file" | grep -q -e "root" -e "proxy"; then
            echo "기본 디렉터리 설정값이 없음."
            echo ""
        else
            grep -v '^[[:space:]]*#' "$conf_file" | grep -A5 -B5 -e "root" -e "proxy"
            echo ""
        fi
    done < NGINX_CONF_FILE_LIST.txt

    echo "]]></DATA>" 

	echo "</Code>" 
    
} >> "$RESULT_FILE" 2>&1

# [WN-02] 불필요한 파일 제거 점검
{
    echo "<Code id=\"WM-02\">" 
    echo "<Result>Info</Result>"
    
    echo "<Comment> 운영 상 불필요한 파일의 존재 여부 확인필요</Comment>"
    echo "<DATA><![CDATA["
	echo "---------------------------------------------------"
    echo "설치 경로 하위 디렉터리 확인"
    echo "---------------------------------------------------"
    if [ -d "$Nginx" ]; then
        ls -alD "$Nginx"
    else
        echo "Nginx 설치 디렉터리가 존재하지 않음"
    fi
	
    echo "]]></DATA>" 
	echo "</Code>"
} >> "$RESULT_FILE" 2>&1

# [WN-03] 심볼릭 링크 사용금지 점검
{
    echo "<Code id=\"WM-03\">" 
    echo "<Comment> 링크 사용금지</Comment>"
    

    # 심볼릭 링크 disable 설정 상태 집계용 변수 초기화
    NGINX_CNT=0   # on 아닌 설정 개수 (off 및 미설정 포함)
    NGINX_CNT1=0  # off 설정 개수
	
    # 각 conf 파일별 disable_symlinks on/off 개수 집계
    while read -r conf_file; do
        if grep -v '^[[:space:]]*#' "$conf_file" | grep -q "disable_symlinks" ; then
            if grep -v '^[[:space:]]*#' "$conf_file" | grep "disable_symlinks" | grep -q "on"; then
                # on 설정
                :
            else
                # off 설정
                NGINX_CNT1=$((NGINX_CNT1 + 1))
            fi
        else
            NGINX_CNT=$((NGINX_CNT + 1))
        fi
    done < NGINX_CONF_FILE_LIST.txt

    # 메인 nginx.conf 기준 취약/양호 판단
    if [ -f "$Nginx_conf" ]; then
        if ! grep -v '^[[:space:]]*#' "$Nginx_conf" | grep -q "disable_symlinks on"; then
            # nginx.conf에 on 설정 없으면 취약
            echo "<Result>Weak</Result>"
            echo "[Comment]: 심볼릭 링크에 대한 Disable 설정이 존재하지 않으므로 취약"
        else
            if [ "$NGINX_CNT1" -ne 0 ]; then
                echo "<Result>Weak</Result>"
                echo "<Comment> 심볼릭 링크에 대한 Disable 설정이 존재하지 않으므로 취약</Comment> "
            elif [ "$NGINX_CNT" -eq 0 ]; then
                echo "<Result>Good</Result>"
                echo "<Comment> 심볼릭 링크에 대한 Disable 설정이 존재하므로 양호</Comment> "
            else
                echo "<Result>Info</Result>"
                echo "<Comment> nginx.conf의 심볼릭 링크에 대한 Disable 설정값 위치 확인 필요</Comment> "
            fi
        fi
    else
        echo "<Result>Info</Result>"
        echo "<Comment> $Nginx_conf 파일이 존재하지 않음</Comment>"
    fi

	echo "<DATA><![CDATA["
    # 각 conf 파일 disable_symlinks 내용 출력
    while read -r conf_file; do
        echo "---------------------------------------------------"
        ls -al "$conf_file"
        echo "---------------------------------------------------"
        if ! grep -v '^[[:space:]]*#' "$conf_file" | grep -q "disable_symlinks"; then
            echo "심볼릭 링크에 대한 Disable 설정값이 없음."
            echo ""
        else
            grep "disable_symlinks" "$conf_file" | egrep -v '^[[:space:]]*#'
            echo ""
        fi
    done < NGINX_CONF_FILE_LIST.txt

    echo ""
    echo "[Check]: 심볼릭 링크, aliases 사용이 금지되어 있으면 양호"
    echo "※ 심볼릭 링크 사용금지 설정이 on시 양호, 설정이 없으면 취약"
    echo "※ Default: disable_symlinks off 설정"
    echo ""
    echo "※ <nginx 설정파일 구조>"
    echo "※   http{"
    echo "※    server{"
    echo "※     location{}}}"
    echo "]]></DATA>" 
	echo "</Code>"
    
} >> "$RESULT_FILE" 2>&1

# [WN-04] 파일 업로드 및 다운로드 제한 점검
{
    echo "<Code id=\"WM-04\">" 
    echo "<Comment> 파일 업로드 및 다운로드 제한</Comment>"
	

    NGINX_CNT=0
    while read -r conf_file; do
        if grep -v '^[[:space:]]*#' "$conf_file" | grep -q "client_max_body_size"; then
            NGINX_CNT=$((NGINX_CNT + 1))
        fi
    done < NGINX_CONF_FILE_LIST.txt

    if [ -f "$Nginx_conf" ]; then
        if ! grep -v '^[[:space:]]*#' "$Nginx_conf" | grep -q "client_max_body_size" && [ "$NGINX_CNT" -eq 0 ]; then
            echo "<Result>Good</Result>"
            echo "<Comment> 파일 업로드 및 다운로드 용량을 제한설정이 적용되어 있으므로 양호</Comment>"
        else
            echo "<Result>Info</Result>"
            echo "<Comment> 파일 업로드 및 다운로드 용량 제한 여부 확인필요</Comment>"
        fi
    else
        echo "<Result>Info</Result>"
        echo "<Comment> $Nginx_conf 파일이 존재하지 않음</Comment>"
    fi

	echo "<DATA><![CDATA["
    while read -r conf_file; do
        echo "---------------------------------------------------"
        ls -al "$conf_file"
        echo "---------------------------------------------------"
        if ! grep -v '^[[:space:]]*#' "$conf_file" | grep -q "client_max_body_size"; then
            echo "<Result>Weak</Result>" 
			echo "파일 업로드 및 다운로드 용량 제한 설정값이 없음."
            echo ""
        else
            grep "client_max_body_size" "$conf_file" | egrep -v '^[[:space:]]*#'
            echo ""
        fi
    done < NGINX_CONF_FILE_LIST.txt

    
    echo "[Check]: 파일 업로드 및 다운로드 용량이 제한되어 있으면 양호"
    echo "※ Default: client_max_body_size 1m;"
    echo "]]></DATA>" 
	echo "</Code>"
} >> "$RESULT_FILE" 2>&1

# [WN-05] 디렉토리 리스팅 제거 점검
{
    echo "<Code id=\"WM-05\">" 
    
    NGINX_CNT=0
    while read -r conf_file; do
        if grep -v '^[[:space:]]*#' "$conf_file" | grep -q "autoindex on"; then
            NGINX_CNT=$((NGINX_CNT + 1))
        fi
    done < NGINX_CONF_FILE_LIST.txt

    if [ -f "$Nginx_conf" ]; then
        if ! grep -v '^[[:space:]]*#' "$Nginx_conf" | grep -q "autoindex on"; then
            if [ "$NGINX_CNT" -eq 0 ]; then
                echo "<Result>Good</Result>"
                echo "<Comment> 디렉터리 리스팅이 제거되어 있으므로 양호</Comment>"
            else
                echo "<Result>Weak</Result>"
                echo "<Comment> 디렉터리 리스팅이 제거되어 있지 않으므로 취약<Comment>"
            fi
        else
            echo "<Result>Weak</Result>"
            echo "<Comment> 디렉터리 리스팅이 제거되어 있지 않으므로 취약<Comment>"
        fi
    else
        echo "<Result>Info</Result>"
        echo "<Comment> $Nginx_conf 파일이 존재하지 않음</Comment>"
    fi


	echo "<DATA><![CDATA["
    while read -r conf_file; do
        echo "---------------------------------------------------"
        ls -al "$conf_file"
        echo "---------------------------------------------------"
        if ! grep -v '^[[:space:]]*#' "$conf_file" | grep -q "autoindex"; then
            echo "디렉터리 리스팅 설정값이 없음."
            echo ""
        else
            grep "autoindex" "$conf_file" | egrep -v '^[[:space:]]*#'
            echo ""
        fi
    done < NGINX_CONF_FILE_LIST.txt

    echo ""
    echo "[Check]: 디렉터리 리스팅 설정이 제거되어 있으면 양호"
    echo "※ 디렉터리 리스팅 설정이 없거나, off시 양호"
    echo "※ Default: autoindex off;"
    echo "※ 하위의 블록에서 선언된 지시어가 없다면 상위 선언으로 적용됨"
    echo "※ 하위의 블록에서 선언된 지시어가 있다면 상위 선언을 무시하고 적용됨"
    echo "======================================================================================"
    echo ""
	echo "]]> </DATA>"
	echo "</Code>"
} >> "$RESULT_FILE" 2>&1

# [WN-06] 웹 프로세스 권한 제한 점검
{
    echo "<Code id=\"WM-06\">"
	echo "<Result>Info</Result>"
    echo "<Comment>웹 프로세스 권한 확인필요</Comment>"
	echo "<DATA><![CDATA["

    if [ -f "$Nginx_conf" ]; then
        echo "---------------------------------------------------"
        echo "Nginx 프로세스 확인"
        echo "---------------------------------------------------"
        ps -ef | grep nginx | grep -v grep

        echo ""
        echo "---------------------------------------------------"
        echo "Nginx 데몬 user 확인"
        echo "---------------------------------------------------"
        grep -i "user" "$Nginx_conf" | grep -vE "log|user_agent"
    else
        echo "---------------------------------------------------"
        echo "Nginx 프로세스 확인"
        echo "---------------------------------------------------"
        ps -ef | grep nginx | grep -v grep
        echo ""
        echo "---------------------------------------------------"
        echo "Nginx 데몬 user 확인"
        echo "---------------------------------------------------"
        echo "$Nginx_conf 파일이 존재하지 않음"
    fi

    echo ""
    echo "[Check]: 웹 서버 프로세스 데몬이 root 권한으로 구동되지 않으면 양호"
    echo "※ Default: nobody로 설정됨"
    echo "======================================================================================"
    echo "]]> </DATA>"
	echo "</Code>"
} >> "$RESULT_FILE" 2>&1

# [WA-07] 안정화 버전 및 패치 적용 점검
{
    echo "<Code id=\"WM-07\">"
	echo "<Result>Info</Result>"
	echo "<Commnet>최신 패치 적용 여부 확인필요</Comment>"
    echo "<DATA><![CDATA["
	echo "---------------------------------------------------"
    echo "소스 버전"
    echo "---------------------------------------------------"
    if [ -x "$Nginx/sbin/nginx" ]; then
        "$Nginx/sbin/nginx" -v
    else
        echo "소스 설치 아님"
    fi
    echo ""
    echo "---------------------------------------------------"
    echo "패키지 버전"
    echo "---------------------------------------------------"
    if grep -qiE "rhel|centos" /etc/*release 2>/dev/null; then
        rpm -qa nginx > nginx_rpm_check.txt 2>/dev/null
        if [ ! -s nginx_rpm_check.txt ]; then
            echo "rpm 버전이 설치되지 않음"
        else
            cat nginx_rpm_check.txt
        fi
    fi
    if grep -qiE "ubuntu|debian" /etc/*release 2>/dev/null; then
        dpkg -l | grep -i nginx > nginx_dpkg_check.txt 2>/dev/null
        if [ ! -s nginx_dpkg_check.txt ]; then
            echo "dpkg 버전이 설치되지 않음"
        else
            awk '{if ($2=="nginx") print $3}' nginx_dpkg_check.txt
        fi
    fi
    echo ""
    echo "[Check]: 최신 패치가 적용되어 있으면 양호"
    echo "======================================================================================"
    echo ""
	echo "]]> </DATA>"
	echo "</Code>"
} >> "$RESULT_FILE" 2>&1

# Nginx 진단 종료 및 설정파일 전체 출력
{
    echo "Nginx 진단 종료"
    echo "<Information>"
	echo "<DATA><![CDATA["
    case $nginx_pkg in
    1)
        cat /etc/nginx/sites-available/default
        ;;
    2)
        echo "---------------------------------------------------"
        ls -al "$Nginx_conf"
        echo "---------------------------------------------------"
        cat "$Nginx_conf"
        echo "---------------------------------------------------"
        ls -al /etc/nginx/conf.d/default.conf
        echo "---------------------------------------------------"
        cat /etc/nginx/conf.d/default.conf
        ;;
    esac

    while read -r conf_file; do
        echo "---------------------------------------------------"
        ls -al "$conf_file"
        echo "---------------------------------------------------"
        cat "$conf_file"
    done < NGINX_CONF_FILE_LIST.txt

    echo "======================================================================================"
    echo ""
	echo "]]> </DATA>"
	echo "</Information>"
	
	echo "</CSAP-CCE>"
} >> "$RESULT_FILE" 2>&1

# 임시파일 삭제
rm -f nginx_rpm_check.txt nginx_dpkg_check.txt NGINX_CONF_FILE_LIST.txt NGINX_CONF_FILE_LIST_TMP.txt
