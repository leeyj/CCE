#!/bin/bash
LANG=C
export LANG
alias ls=ls
AP_STR="Kubernetes(Master)"
HOST_NAME=$(hostname)
IP_ADDR=$(hostname -I | awk '{print $1}')
DATE_STR=$(date +%m%d)
RESULT_FILE="${HOST_NAME}_${AP_STR}_${DATE_STR}.xml"

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" > $RESULT_FILE
echo "<CSAP-CCE>" >> $RESULT_FILE
echo "  <info>" >> $RESULT_FILE
echo "    <index>K8S-MASTER</index>" >> $RESULT_FILE
echo "    <IPAddress>$IP_ADDR</IPAddress>" >> $RESULT_FILE
echo "    <HOSTNAME>$HOST_NAME</HOSTNAME>" >> $RESULT_FILE
echo "  </info>" >> $RESULT_FILE

# 점검 함수
KM_01(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>API server 비인증 접근 차단</Comment>" >> $RESULT_FILE
if grep -q "\-\-anonymous-auth=false" /etc/kubernetes/manifests/kube-apiserver.yaml 2>/dev/null; then
   echo "    <Result>Good</Result>" >> $RESULT_FILE
else
   echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/kube-apiserver.yaml | egrep -i "anonymous-auth|insecure-|service-account-lookup" >> $RESULT_FILE
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_02(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>API server 취약한 방식의 인증사용 제한</Comment>" >> $RESULT_FILE
if ! grep -qi "token-auth-file" /etc/kubernetes/manifests/kube-apiserver.yaml 2>/dev/null; then
   echo "    <Result>Good</Result>" >> $RESULT_FILE
else
   echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/kube-apiserver.yaml | egrep -i "token-auth-file" >> $RESULT_FILE
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_03(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>API server 서비스 API 외부 오픈 금지</Comment>" >> $RESULT_FILE
if grep -q "127.0.0.1" /etc/kubernetes/manifests/kube-scheduler.yaml 2>/dev/null && grep -q "127.0.0.1" /etc/kubernetes/manifests/kube-controller-manager.yaml 2>/dev/null; then
    echo "    <Result>Good</Result>" >> $RESULT_FILE
else
    echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/kube-scheduler.yaml | egrep -i "bind-address"
cat /etc/kubernetes/manifests/kube-controller-manager.yaml | egrep -i "bind-address"
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}


KM_04(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>API server 권한 제어</Comment>" >> $RESULT_FILE
if ! grep -qi "authorization-mode=AlwaysAllow" /etc/kubernetes/manifests/kube-apiserver.yaml 2>/dev/null; then
    echo "    <Result>Good</Result>" >> $RESULT_FILE
else
    echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/kube-apiserver.yaml | grep -i "authorization-mode"
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_05(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>Admission Control Plugin 설정</Comment>" >> $RESULT_FILE
if grep -qi "enable-admission-plugins" /etc/kubernetes/manifests/kube-apiserver.yaml 2>/dev/null; then
    echo "    <Result>Good</Result>" >> $RESULT_FILE
else
    echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/kube-apiserver.yaml | egrep -i "enable-admission-plugins|disable-admission-plugins|admission-control-config-file"
admissionfile=$(grep -i "admission-control-config-file" /etc/kubernetes/manifests/kube-apiserver.yaml | awk -F= '{print $2}')
if [[ -f $admissionfile ]]; then
    cat "$admissionfile"
fi
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}


KM_06(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>API server SSL/TLS 적용</Comment>" >> $RESULT_FILE
if grep -q "\-\-secure-port=[^0]" /etc/kubernetes/manifests/kube-apiserver.yaml 2>/dev/null; then
   echo "    <Result>Good</Result>" >> $RESULT_FILE
else
   echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/kube-apiserver.yaml | egrep -i "\-\-secure-port|\-\-tls-cert-file|\-\-tls-private-key-file|\-\-client-ca-file|\-\-kubelet-certificate-authority|\-\-kubelet-client-certificate|\-\-kubelet-client-key|\-\-service-account-key-file|\-\-tls-ciphersuites" >> $RESULT_FILE
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_07(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>API server 로그 관리</Comment>" >> $RESULT_FILE
if grep -q "\-\-audit-log-path" /etc/kubernetes/manifests/kube-apiserver.yaml 2>/dev/null; then
   echo "    <Result>Good</Result>" >> $RESULT_FILE
else
   echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/kube-apiserver.yaml | egrep -i "audit-log-path|audit-log-maxbackup|audit-log-maxsize|audit-log-maxage|audit-policy-file"
AUDIT_POLICY=$(grep -i "audit-policy-file" /etc/kubernetes/manifests/kube-apiserver.yaml | awk -F= '{print $2}')
if [ -f "$AUDIT_POLICY" ]; then cat "$AUDIT_POLICY"; fi
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_08(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>Controller 인증 제어</Comment>" >> $RESULT_FILE
if grep -qi "\-\-use-service-account-credentials=true" /etc/kubernetes/manifests/kube-controller-manager.yaml 2>/dev/null && grep -qi "\-\-service-account-private-key-file" /etc/kubernetes/manifests/kube-controller-manager.yaml 2>/dev/null; then
   echo "    <Result>Good</Result>" >> $RESULT_FILE
else
   echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/kube-controller-manager.yaml | egrep -i "\-\-use-service-account-credentials|\-\-service-account-private-key-file"
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_09(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>Controller Manager SSL/TLS 적용</Comment>" >> $RESULT_FILE
if grep -qi "\-\-root-ca-file" /etc/kubernetes/manifests/kube-controller-manager.yaml 2>/dev/null; then
   echo "    <Result>Good</Result>" >> $RESULT_FILE
else
   echo "    <Result>Info</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/kube-controller-manager.yaml | egrep -i "\-\-root-ca-file|\-\-feature-gates"
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_10(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>etcd 암호화 적용</Comment>" >> $RESULT_FILE
if grep -qi "\-\-encryption-provider-config" /etc/kubernetes/manifests/kube-apiserver.yaml 2>/dev/null; then
  echo "    <Result>Good</Result>" >> $RESULT_FILE
else
  echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/kube-apiserver.yaml | grep -i "\-\-encryption-provider-config"
ps -ef | grep kube-apiserver | grep -v grep
ETCD_ENC=$(grep -i "\-\-encryption-provider-config" /etc/kubernetes/manifests/kube-apiserver.yaml | awk -F= '{print $2}')
if [ -f "$ETCD_ENC" ]; then cat "$ETCD_ENC"; fi
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_11(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>etcd SSL/TLS 적용</Comment>" >> $RESULT_FILE
if grep -qi "\-\-client-cert-auth=true" /etc/kubernetes/manifests/etcd.yaml 2>/dev/null &&
   grep -qi "\-\-cert-file" /etc/kubernetes/manifests/etcd.yaml 2>/dev/null &&
   grep -qi "\-\-key-file" /etc/kubernetes/manifests/etcd.yaml 2>/dev/null; then
   echo "    <Result>Good</Result>" >> $RESULT_FILE
else
   echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/etcd.yaml | egrep -i "\-\-client-cert-auth|\-\-peer-client-cert-auth|\-\-cert-file|\-\-key-file|\-\-peer-cert-file|\-\-peer-key-file|\-\-auto-tls|\-\-peer-auto-tls|\-\-trusted-ca-file"
cat /etc/kubernetes/manifests/kube-apiserver.yaml | egrep -i "\-\-etcd-certfile|\-\-etcd-keyfile|\-\-etcd-cafile"
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_12(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>컨테이너 권한 제어</Comment>" >> $RESULT_FILE
if grep -qi "enable-admission-plugins=.*PodSecurityPolicy" /etc/kubernetes/manifests/kube-apiserver.yaml 2>/dev/null; then
   echo "    <Result>Good</Result>" >> $RESULT_FILE
else
   echo "    <Result>Info</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/kube-apiserver.yaml | grep -i "enable-admission-plugins"
# PodSecurityPolicy 파일이 존재할 경우 추가 cat
if [ -f "$PodSecurityPolicy" ]; then cat "$PodSecurityPolicy"; fi
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_13(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>네임스페이스 공유 금지</Comment>" >> $RESULT_FILE
if grep -qi "enable-admission-plugins=.*PodSecurityPolicy" /etc/kubernetes/manifests/kube-apiserver.yaml 2>/dev/null; then
   echo "    <Result>Good</Result>" >> $RESULT_FILE
else
   echo "    <Result>Info</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
cat /etc/kubernetes/manifests/kube-apiserver.yaml | grep -i "enable-admission-plugins"
if [ -f "$PodSecurityPolicy" ]; then cat "$PodSecurityPolicy"; fi
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_14(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>환경설정 파일 권한 설정</Comment>" >> $RESULT_FILE
if [ -d /etc/kubernetes ] && [ $(find /etc/kubernetes -type f ! -perm -644 | wc -l) -eq 0 ]; then
   echo "    <Result>Good</Result>" >> $RESULT_FILE
else
   echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
ls -alR /etc/kubernetes 2>/dev/null
if [ -d /etc/cni/net.d ]; then
  echo "/etc/cni/net.d 경로"
  stat -c %U:%G:%a /etc/cni/net.d
  echo "CNI 파일"
  ls -al /etc/cni/net.d
fi
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_15(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>인증서 파일 권한 설정</Comment>" >> $RESULT_FILE
if [ "$(find /etc/kubernetes/pki/ -name '*.key' -perm -600 2>/dev/null | wc -l)" -eq "$(ls /etc/kubernetes/pki/*.key 2>/dev/null | wc -l)" ] &&
   [ "$(find /etc/kubernetes/pki/ -name '*.crt' -perm -644 2>/dev/null | wc -l)" -eq "$(ls /etc/kubernetes/pki/*.crt 2>/dev/null | wc -l)" ]; then
   echo "    <Result>Good</Result>" >> $RESULT_FILE
else
   echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
ls -laR /etc/kubernetes/pki/ 2>/dev/null
ls -laR /etc/kubernetes/pki/*.crt 2>/dev/null
ls -laR /etc/kubernetes/pki/*.key 2>/dev/null
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_16(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>etcd 데이터 디렉터리 권한 설정</Comment>" >> $RESULT_FILE
if [ -d /var/lib/etcd ]; then
  PERM=$(stat -c %a /var/lib/etcd)
  if [ "$PERM" -le "700" ]; then
    echo "    <Result>Good</Result>" >> $RESULT_FILE
  else
    echo "    <Result>Weak</Result>" >> $RESULT_FILE
  fi
else
  echo "    <Result>Info</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
if [ -d /var/lib/etcd ]; then
  stat -c %U:%G:%a /var/lib/etcd
else
  echo "/var/lib/etcd 경로가 존재하지 않음"
fi
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}

KM_17(){
CODE=$1
echo "  <CODE Id=\"$CODE\">" >> $RESULT_FILE
echo "    <Comment>최신 보안 패치 적용</Comment>" >> $RESULT_FILE
KVER=$(kubectl version --short 2>/dev/null | grep 'Server Version' | awk '{print $3}')
if [[ "$KVER" == "" ]]; then
  echo "    <Result>Info</Result>" >> $RESULT_FILE
elif [[ "$KVER" =~ 1\.(2[0-9]|3[0-9]|\d{3,}) ]]; then
  echo "    <Result>Good</Result>" >> $RESULT_FILE
else
  echo "    <Result>Weak</Result>" >> $RESULT_FILE
fi
echo "    <DATA><![CDATA[" >> $RESULT_FILE
kubectl version 2>/dev/null
echo "    ]]></DATA>" >> $RESULT_FILE
echo "  </CODE>" >> $RESULT_FILE
}


# 메인 실행부 ────────────────────────────────────────────
KM_01 'KM-01'
KM_02 'KM-02'
KM_03 'KM-03'
KM_04 'KM-04'
KM_05 'KM-05'
KM_06 'KM-06'
KM_07 'KM-07'
KM_08 'KM-08'
KM_09 'KM-09'
KM_10 'KM-10'
KM_11 'KM-11'
KM_12 'KM-12'
KM_13 'KM-13'
KM_14 'KM-14'
KM_15 'KM-15'
KM_16 'KM-16'
KM_17 'KM-17'

echo "</CSAP-CCE>" >> $RESULT_FILE
